create trigger after_ins_op
  after INSERT
  on children
  for each row
  INSERT INTO settings (c_id,parental_opt_id,security_opt_id,backend_opt_id) VALUES (new.c_id,0,0,0);

