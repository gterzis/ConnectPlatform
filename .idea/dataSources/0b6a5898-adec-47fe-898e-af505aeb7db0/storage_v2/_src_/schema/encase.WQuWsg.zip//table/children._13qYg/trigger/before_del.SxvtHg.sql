create trigger before_del
  before DELETE
  on children
  for each row
  DELETE FROM settings WHERE c_id = old.c_id;

